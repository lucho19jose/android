package com.example.persona;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class formulario extends AppCompatActivity {
    //... declarar atributos
    private EditText aDNI, aApellidos, aNombres, aCodigo, aSingreso;
    private RadioButton aMasculino, aFemenino;
    private Spinner aEcivil, aEprofesional;
    private GridView aTabla;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario);
        //... establecer enlace persona
        aDNI= findViewById(R.id.etDNI);
        aApellidos= findViewById(R.id.etApellidos);
        aNombres= findViewById(R.id.etNombres);
        aMasculino= findViewById(R.id.rbMasculino);
        aFemenino= findViewById(R.id.rbFemenino);
        aEcivil= findViewById(R.id.spEcivil);
        //... establecer enlace estudiante
        aCodigo= findViewById(R.id.etCodigo);
        aEprofesional= findViewById(R.id.spEprofesional);
        aSingreso= findViewById(R.id.etSingreso);
        //... establecer datos para mostrar tabla de datos
        aTabla= findViewById(R.id.gvTabla);
        //... cargar objetos
        cargarObjetos();
    }
    //... metodos privados
    private void cargarObjetos(){
        //... cargar estado civil
        String []eCivil= new String[]{"Soltero (a)", "Casado (a)", "Viudo (a)", "Divorsiado (a)"};
        ArrayAdapter<String> ec= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, eCivil);
        aEcivil.setAdapter(ec);
        //... cargar escuela profesional
        ArrayAdapter<String> ep= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        ep.add("Administración"); ep.add("Agroindustrial"); ep.add("Ambiental"); ep.add("Contabilidad");
        ep.add("Educación"); ep.add("Sistemas");
        aEprofesional.setAdapter(ep);
    }
    private int sexo(boolean pMasculino, boolean pFemenino){
        int s= -1;
        if(pMasculino)
            s= 1;
        if(pFemenino)
            s= 0;
        return s;
    }
    private void limpiarVentana(){
        //... limpiar persona
        aDNI.setText("");
        aApellidos.setText("");
        aNombres.setText("");
        aMasculino.setChecked(true);
        aEcivil.setSelection(0);
        //... limpiar estudiante
        aCodigo.setText("");
        aEprofesional.setSelection(0);
        aSingreso.setText("");
    }
    //... regitrar
    public void registrar(View view){
        //... creando un registro
        SharedPreferences estudiante= getSharedPreferences(aDNI.getText().toString(), Context.MODE_PRIVATE);
        SharedPreferences.Editor editar= estudiante.edit();
        //... registrar persona
        editar.putString("dni", aDNI.getText().toString());
        editar.putString("apellidos", aApellidos.getText().toString());
        editar.putString("nombres", aNombres.getText().toString());
        editar.putInt("sexo", sexo(aMasculino.isChecked(), aFemenino.isChecked()));
        editar.putInt("eCivil", aEcivil.getSelectedItemPosition());
        editar.commit();
        //... registrar estudiante
        Toast.makeText(this, "Registro satisfactorio...", Toast.LENGTH_LONG).show();
        //... limpiar ventana
        limpiarVentana();
    }
    //... boton mostrar
    public void mostrar(View view){
        SharedPreferences estudiante= getSharedPreferences(aDNI.getText().toString(), Context.MODE_PRIVATE);
        if(estudiante.getString("dni", "").equals("")) {
            Toast.makeText(this, "El DNI, no existe en el registro...", Toast.LENGTH_LONG).show();
            limpiarVentana();
        }
        else{
            aApellidos.setText(estudiante.getString("apellidos", ""));
            aNombres.setText(estudiante.getString("nombres", ""));
            int sexo= estudiante.getInt("sexo", -1);
            if(sexo==1)
                aMasculino.setChecked(true);
            if(sexo==0)
                aFemenino.setChecked(true);
            aEcivil.setSelection(estudiante.getInt("eCivil", 0));
        }
    }
}
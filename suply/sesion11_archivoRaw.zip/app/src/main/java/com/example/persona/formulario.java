package com.example.persona;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RadioButton;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class formulario extends AppCompatActivity {
    //... declarar atributos
    private EditText aDNI, aApellidos, aNombres, aCodigo, aSingreso;
    private RadioButton aMasculino, aFemenino;
    private Spinner aEcivil, aEprofesional;
    private GridView aTabla;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario);
        //... establecer enlace persona
        aDNI= findViewById(R.id.etDNI);
        aApellidos= findViewById(R.id.etApellidos);
        aNombres= findViewById(R.id.etNombres);
        aMasculino= findViewById(R.id.rbMasculino);
        aFemenino= findViewById(R.id.rbFemenino);
        aEcivil= findViewById(R.id.spEcivil);
        //... establecer enlace estudiante
        aCodigo= findViewById(R.id.etCodigo);
        aEprofesional= findViewById(R.id.spEprofesional);
        aSingreso= findViewById(R.id.etSingreso);
        //... establecer datos para mostrar tabla de datos
        aTabla= findViewById(R.id.gvTabla);
        //... cargar objetos
        cargarObjetos();
    }
    //... metodos privados
    private void cargarObjetos(){
        //... cargar estado civil
        String []eCivil= new String[]{"Soltero (a)", "Casado (a)", "Viudo (a)", "Divorsiado (a)"};
        ArrayAdapter<String> ec= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, eCivil);
        aEcivil.setAdapter(ec);
        //... cargar escuela profesional
        ArrayAdapter<String> ep= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        ep.add("Administración"); ep.add("Agroindustrial"); ep.add("Ambiental"); ep.add("Contabilidad");
        ep.add("Educación"); ep.add("Sistemas");
        aEprofesional.setAdapter(ep);
    }
    private int sexo(boolean pMasculino, boolean pFemenino){
        int s= -1;
        if(pMasculino)
            s= 1;
        if(pFemenino)
            s= 0;
        return s;
    }
    private void limpiarVentana(){
        //... limpiar persona
        aDNI.setText("");
        aApellidos.setText("");
        aNombres.setText("");
        aMasculino.setChecked(true);
        aEcivil.setSelection(0);
        //... limpiar estudiante
        aCodigo.setText("");
        aEprofesional.setSelection(0);
        aSingreso.setText("");
    }
    private void mostrarDatos(String[] pDatos){
        aDNI.setText(pDatos[0]);
        aApellidos.setText(pDatos[1]);
        aNombres.setText(pDatos[2]);
        int sexo= Integer.parseInt(pDatos[3]);
        if(sexo==1)
            aMasculino.setChecked(true);
        if(sexo==0)
            aFemenino.setChecked(true);
        aEcivil.setSelection(Integer.parseInt(pDatos[4]));
    }
    //... regitrar
    public void mujer(View view) {
        InputStream archivo= this.getResources().openRawResource(R.raw.mujer);
        BufferedReader br= new BufferedReader(new InputStreamReader(archivo));
        try{
            String linea= br.readLine();
            String[] datos= new String[5];//... dni-apellidos-nombres-sexo-eCivil
            int i= 0;
            while (linea!=null){
                datos[i]= linea;
                linea= br.readLine();
                i++;
            }
            br.close();
            archivo.close();
            mostrarDatos(datos);
        }catch (IOException err){ System.err.println(); }
    }
    //... boton mostrar varon
    public void varon(View view){
        InputStream archivo= this.getResources().openRawResource(R.raw.varon);
        BufferedReader br= new BufferedReader(new InputStreamReader(archivo));
        try{
            String linea= br.readLine();
            String[] datos= new String[5];//... dni-apellidos-nombres-sexo-eCivil
            int i= 0;
            while (linea!=null){
                datos[i]= linea;
                linea= br.readLine();
                i++;
            }
            br.close();
            archivo.close();
            mostrarDatos(datos);
        }catch (IOException err){ System.err.println(); }
    }
}
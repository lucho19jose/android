package com.example.sonido;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class audio extends AppCompatActivity {
    //... atributo
    private Button aPlay;
    private SoundPool aSp;
    private int aSonido;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);
        //... establecer enlace
        aPlay= findViewById(R.id.buSoundP);
        aSp= new SoundPool(1, AudioManager.STREAM_MUSIC, 1);
        aSonido= aSp.load(this, R.raw.soundpool, 1);
    }
    public void soundPool(View view){
        aSp.play(aSonido, 1, 1, 1, 0, 0);
    }
    public void mediaPlayer(View view){
        MediaPlayer mp= MediaPlayer.create(this, R.raw.mediaplayer);
        mp.start();
    }
}
package com.example.persona;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class formulario extends AppCompatActivity {
    //... declarar atributos
    private EditText aDNI, aApellidos, aNombres, aSexo, aEcivil;
    private TextView aMostrar;
    private cPersona aP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario);
        //... establecer enlace xml
        aDNI= findViewById(R.id.etDNI);
        aApellidos= findViewById(R.id.etApellidos);
        aNombres= findViewById(R.id.etNombre);
        aSexo= findViewById(R.id.etSexo);
        aEcivil= findViewById(R.id.etEcivil);
        aMostrar= findViewById(R.id.tvMostrar);
        //... construir clase
        aP= new cPersona();
    }
    //... metodos privados
    private void limpiarVentana(){
        aDNI.setText("");
        aApellidos.setText("");
        aNombres.setText("");
        aSexo.setText("");
        aEcivil.setText("");
    }
    //... regitrar
    public void registrar(View view){
        if(aP.mDNI(aDNI.getText().toString())){
            aP.mApellidos(aApellidos.getText().toString());
            aP.mNombres(aNombres.getText().toString());
            aP.mSexo(aSexo.getText().toString());
            aP.mEcivil(aEcivil.getText().toString());
            //... mostrar ventana de registro
            Toast.makeText(this, "Registro satisfactorio...", Toast.LENGTH_LONG).show();
            //... limpiar ventana
            limpiarVentana();
        }else
            Toast.makeText(this, "DNI incorrecto...", Toast.LENGTH_LONG).show();
    }
    //... mostrar
    public void mostrar(View view){
        String persona= "Persona:\n";
        persona= persona+"DNI: "+aP.sDNI()+"\n";
        persona= persona+"Apellidos: "+aP.sApellidos()+"\n";
        persona= persona+"Nombres: "+aP.sNombres()+"\n";
        persona= persona+"Sexo: "+aP.sSexo()+"\n";
        persona= persona+"Estado civil: "+aP.sEcivil()+"\n";
        aMostrar.setText(persona);
    }
}
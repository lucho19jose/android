package com.example.persona;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class formulario extends AppCompatActivity {
    //... declarar atributos
    private EditText aDNI, aApellidos, aNombres, aCodigo, aSingreso;
    private RadioButton aMasculino, aFemenino;
    private Spinner aEcivil, aEprofesional;
    private GridView aTabla;
    private cEstudiante aE;
    //... lista tabla
    private ArrayAdapter<String> e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario);
        //... establecer enlace persona
        aDNI= findViewById(R.id.etDNI);
        aApellidos= findViewById(R.id.etApellidos);
        aNombres= findViewById(R.id.etNombres);
        aMasculino= findViewById(R.id.rbMasculino);
        aFemenino= findViewById(R.id.rbFemenino);
        aEcivil= findViewById(R.id.spEcivil);
        //... establecer enlace estudiante
        aCodigo= findViewById(R.id.etCodigo);
        aEprofesional= findViewById(R.id.spEprofesional);
        aSingreso= findViewById(R.id.etSingreso);
        //... establecerdatos para mostrar tabla de datos
        aTabla= findViewById(R.id.gvTabla);
        //... construir clase
        aE= new cEstudiante();
        //... cargar objetos
        cargarObjetos();
    }
    //... metodos privados
    private void limpiarVentana(){
        //... limpiar persona
        aDNI.setText("");
        aApellidos.setText("");
        aNombres.setText("");
        aMasculino.setChecked(true);
        aEcivil.setSelection(0);
        //... limpiar estudiante
        aCodigo.setText("");
        aEprofesional.setSelection(0);
        aSingreso.setText("");
    }
    private void mostrarTabla(){
        e.add(aE.sDNI());
        e.add(aE.sNombres());
        e.add(aE.sApellidos());
        aTabla.setAdapter(e);
    }
    private void cargarObjetos(){
        //... cargar estado civil
        String []eCivil= new String[]{"Soltero (a)", "Casado (a)", "Viudo (a)", "Divorsiado (a)"};
        ArrayAdapter<String> ec= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, eCivil);
        aEcivil.setAdapter(ec);
        //... cargar escuela profesional
        ArrayAdapter<String> ep= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        ep.add("Administración"); ep.add("Agroindustrial"); ep.add("Ambiental"); ep.add("Contabilidad");
        ep.add("Educación"); ep.add("Sistemas");
        aEprofesional.setAdapter(ep);
        //... cargar etiquetas de datos
        e= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        e.add("DNI"); e.add("Nombres"); e.add("Apellidos");
        aTabla.setNumColumns(3);
        aTabla.setAdapter(e);
    }
    private int sexo(boolean pMasculino, boolean pFemenino){
        int s= -1;
        if(pMasculino)
            s= 1;
        if(pFemenino)
            s= 0;
        return s;
    }
    //... regitrar
    public void registrar(View view){
        //... registrar persona
        aE.mDNI(aDNI.getText().toString());
        aE.mApellidos(aApellidos.getText().toString());
        aE.mNombres(aNombres.getText().toString());
        aE.mSexo(sexo(aMasculino.isChecked(), aFemenino.isChecked()));
        //aE.mEcivil(aEcivil.getItemAtPosition(aEcivil.getSelectedItemPosition()).toString());
        aE.mEcivil(aEcivil.getSelectedItemPosition());
        //... registrar estudiante
        aE.mCodigo(aCodigo.getText().toString());
        aE.mEprofesional(aEprofesional.getSelectedItemPosition());
        aE.mSingreso(aSingreso.getText().toString());
        //... mostrar ventana de registro
        Toast.makeText(this, "Registro satisfactorio...", Toast.LENGTH_LONG).show();
        //... limpiar ventana
        limpiarVentana();
        //... mostrar tabla
        mostrarTabla();
    }
    //... mostrar
    public void mostrar(View view){
        //... mostrar persona
        aDNI.setText(aE.sDNI());
        aApellidos.setText(aE.sApellidos());
        aNombres.setText(aE.sNombres());
        if(aE.sSexo()==1)
            aMasculino.setChecked(true);
        if(aE.sSexo()==0)
            aFemenino.setChecked(true);
        aEcivil.setSelection(aE.sEcivil());
        //... mostrar estudiante
        aCodigo.setText(aE.sCodigo());
        aEprofesional.setSelection(aE.sEprofesional());
        aSingreso.setText(aE.sSingreso());
    }
}
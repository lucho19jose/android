package com.example.acelerometro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class cGrafico extends View implements SensorEventListener{
    //... atributos
    private cPelota aP;
    protected cGrafico(Context context){
        super(context);
        //... atributos para control de acelerometro
        SensorManager administrador= (SensorManager)getContext().getSystemService(Context.SENSOR_SERVICE);
        Sensor rotacion= administrador.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        administrador.registerListener(this, rotacion, SensorManager.SENSOR_DELAY_FASTEST);
        Display pantalla= ((WindowManager)getContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        //... inicializar clase
        aP= new cPelota(5, pantalla.getWidth(), pantalla.getHeight());
    }
    public void onDraw(Canvas canvas){
        canvas.drawRGB(255, 255, 255);
        Paint pintar= new Paint();
        dibujarPelota(pintar, canvas);
        dibujarTexto(pintar, canvas);
    }
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        aP.moverPelota((int)sensorEvent.values[0], (int)sensorEvent.values[1], (int)sensorEvent.values[2]);
        invalidate();
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) { }
    //... metodos privados
    private void dibujarPelota(Paint pPintar, Canvas pCanvas){
        pPintar.setColor(Color.RED);
        //... dibujar pelotas
        for(int i= 0; i<aP.sNroP(); i++){
            if(aP.sCordXYZ(i, 1, 1)==1){ //... estado activo
                pCanvas.drawCircle(aP.sCordXYZ(i, 0, 0), aP.sCordXYZ(i, 0, 1),
                        aP.sCordXYZ(i, 0, 2)+aP.sCordXYZ(i, 1, 0), pPintar);
            }
        }
    }
    private void dibujarTexto(Paint pPintar, Canvas pCanvas){
        pPintar.setColor(Color.GREEN);
        pPintar.setTextSize(20);
        for(int i= 0; i<aP.sNroP(); i++) {
            if (aP.sCordXYZ(i, 1, 1)==1) { //... estado activo
                String texto = "(" + aP.sCordXYZ(i, 0, 0) + "," + aP.sCordXYZ(i, 0, 1) + "," + aP.sCordXYZ(i, 0, 2) + ")";
                pCanvas.drawText(texto, aP.sCordXYZ(i, 0, 0) - aP.sCordXYZ(i, 1, 0),
                        aP.sCordXYZ(i, 0, 1) + aP.sCordXYZ(i, 1, 0) / 2, pPintar);
            }
        }
    }
    public void escogerPelota(int pCordX, int pCordY){ aP.escogerPelota(pCordX, pCordY); }
}
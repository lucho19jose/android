package com.example.persona;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class formulario extends AppCompatActivity {
    //... declarar atributos
    private EditText aDNI, aApellidos, aNombres, aCodigo, aSingreso;
    private RadioButton aMasculino, aFemenino;
    private Spinner aEcivil, aEprofesional;
    private GridView aTabla;
    //... lista clase estudiante
    private ArrayList<cEstudiante> aE;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario);
        //... establecer enlace persona
        aDNI= findViewById(R.id.etDNI);
        aApellidos= findViewById(R.id.etApellidos);
        aNombres= findViewById(R.id.etNombres);
        aMasculino= findViewById(R.id.rbMasculino);
        aFemenino= findViewById(R.id.rbFemenino);
        aEcivil= findViewById(R.id.spEcivil);
        //... establecer enlace estudiante
        aCodigo= findViewById(R.id.etCodigo);
        aEprofesional= findViewById(R.id.spEprofesional);
        aSingreso= findViewById(R.id.etSingreso);
        //... establecer datos para mostrar tabla de datos
        aTabla= findViewById(R.id.gvTabla);
        //... construir clase
        aE= new ArrayList<cEstudiante>();
        //... cargar objetos
        cargarObjetos();
    }
    //... metodos privados
    private void mostrarE(int pPosicion){
        cEstudiante e= aE.get(pPosicion);
        aDNI.setText(e.sDNI());
        aApellidos.setText(e.sApellidos());
        aNombres.setText(e.sNombres());
        if(e.sSexo()==1)
            aMasculino.setChecked(true);
        if(e.sSexo()==0)
            aFemenino.setChecked(true);
        aEcivil.setSelection(e.sEcivil());
        //... mostrar estudiante
        aCodigo.setText(e.sCodigo());
        aEprofesional.setSelection(e.sEprofesional());
        aSingreso.setText(e.sSingreso());
    }
    private void mostrarTabla(){
        cEstudiante e;
        int i= 0, t= aE.size();
        ArrayAdapter<String> te= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        te.add("DNI"); te.add("Nombres"); te.add("E. profesional");
        while(i<t){
            //... recuperando estudiante de la lista
            e= aE.get(i);
            //... adiciona al arrarAdapter
            te.add(e.sDNI());
            te.add(e.sNombres());
            te.add(e.sEprofesional()+"");
            i++;
        }
        aTabla.setNumColumns(3);
        aTabla.setAdapter(te);
        //... activar evento clic en la tabla
        aTabla.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int posicion, long id) {
                int pos= posicion/3-1;
                if(pos>=0)
                    mostrarE(pos);
            }
        });
    }
    private void cargarObjetos(){
        //... cargar estado civil
        String []eCivil= new String[]{"Soltero (a)", "Casado (a)", "Viudo (a)", "Divorsiado (a)"};
        ArrayAdapter<String> ec= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, eCivil);
        aEcivil.setAdapter(ec);
        //... cargar escuela profesional
        ArrayAdapter<String> ep= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        ep.add("Administración"); ep.add("Agroindustrial"); ep.add("Ambiental"); ep.add("Contabilidad");
        ep.add("Educación"); ep.add("Sistemas");
        aEprofesional.setAdapter(ep);
        //... cargar etiquetas de datos
        mostrarTabla();
    }
    private int sexo(boolean pMasculino, boolean pFemenino){
        int s= -1;
        if(pMasculino)
            s= 1;
        if(pFemenino)
            s= 0;
        return s;
    }
    private void limpiarVentana(){
        //... limpiar persona
        aDNI.setText("");
        aApellidos.setText("");
        aNombres.setText("");
        aMasculino.setChecked(true);
        aEcivil.setSelection(0);
        //... limpiar estudiante
        aCodigo.setText("");
        aEprofesional.setSelection(0);
        aSingreso.setText("");
    }
    //... regitrar
    public void registrar(View view){
        cEstudiante e= new cEstudiante();
        //... registrar persona
        e.mDNI(aDNI.getText().toString());
        e.mApellidos(aApellidos.getText().toString());
        e.mNombres(aNombres.getText().toString());
        e.mSexo(sexo(aMasculino.isChecked(), aFemenino.isChecked()));
        //aE.mEcivil(aEcivil.getItemAtPosition(aEcivil.getSelectedItemPosition()).toString());
        e.mEcivil(aEcivil.getSelectedItemPosition());
        //... registrar estudiante
        e.mCodigo(aCodigo.getText().toString());
        e.mEprofesional(aEprofesional.getSelectedItemPosition());
        e.mSingreso(aSingreso.getText().toString());
        //... mostrar ventana de registro
        aE.add(e);
        Toast.makeText(this, "Registro satisfactorio...", Toast.LENGTH_LONG).show();
        //... limpiar ventana
        limpiarVentana();
        //... mostrar tabla
        mostrarTabla();
    }
    //... boton mostrar
    public void mostrar(View view){
        int p= -1, i= 0, t= aE.size();
        //... buscar persona
        while(i<t){
            if(aE.get(i).sDNI().equals(aDNI.getText().toString())) { p= i; i= t; }
            i++;
        }
        if(p>=0) { mostrarE(p); }else {
            Toast.makeText(this, "El DNI, no existe en la lista de estudiantes...", Toast.LENGTH_LONG).show();
            limpiarVentana();
        }
    }
}
package com.example.persona;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class formulario extends AppCompatActivity {
    //... declarar atributos
    private EditText aDNI, aApellidos, aNombres;
    private RadioButton aMasculino, aFemenino;
    private Spinner aEcivil;
    private cPersona aP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formulario);
        //... establecer enlace xml
        aDNI= findViewById(R.id.etDNI);
        aApellidos= findViewById(R.id.etApellidos);
        aNombres= findViewById(R.id.etNombre);
        aMasculino= findViewById(R.id.rbMasculino);
        aFemenino= findViewById(R.id.rbFemenino);
        aEcivil= findViewById(R.id.spEcivil);
        //... construir clase
        aP= new cPersona();
        //... cargar objetos
        cargarObjetos();
    }
    //... metodos privados
    private void limpiarVentana(){
        aDNI.setText("");
        aApellidos.setText("");
        aNombres.setText("");
        aMasculino.setChecked(true);
        aEcivil.setSelection(0);
    }
    private void cargarObjetos(){
        String []eCivil= new String[]{"Soltero (a)", "Casado (a)", "Viudo (a)", "Divorsiado (a)"};
        ArrayAdapter<String> ec= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, eCivil);
        aEcivil.setAdapter(ec);
    }
    private int Ecivil(String pEcivil){
        int ec= 0;
        if(pEcivil.equals("Casado (a)"))
            ec= 1;
        if(pEcivil.equals("Viudo (a)"))
            ec= 2;
        if(pEcivil.equals("Divorsiado (a)"))
            ec= 3;
        return ec;
    }
    //... regitrar
    public void registrar(View view){
        if(aP.mDNI(aDNI.getText().toString())){
            aP.mApellidos(aApellidos.getText().toString());
            aP.mNombres(aNombres.getText().toString());
            if(aMasculino.isChecked())
                aP.mSexo(1);
            if(aFemenino.isChecked())
                aP.mSexo(0);
            //aE.mEcivil(aEcivil.getItemAtPosition(aEcivil.getSelectedItemPosition()).toString());
            aP.mEcivil(Ecivil(aEcivil.getSelectedItem().toString()));
            //... mostrar ventana de registro
            Toast.makeText(this, "Registro satisfactorio...", Toast.LENGTH_LONG).show();
            //... limpiar ventana
            limpiarVentana();
        }else
            Toast.makeText(this, "DNI incorrecto...", Toast.LENGTH_LONG).show();
    }
    //... mostrar
    public void mostrar(View view){
        aDNI.setText(aP.sDNI());
        aApellidos.setText(aP.sApellidos());
        aNombres.setText(aP.sNombres());
        if(aP.sSexo()==1)
            aMasculino.setChecked(true);
        if(aP.sSexo()==0)
            aFemenino.setChecked(true);
        aEcivil.setSelection(aP.sEcivil());
    }
}
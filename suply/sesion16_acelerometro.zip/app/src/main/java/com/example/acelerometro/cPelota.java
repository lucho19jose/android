package com.example.acelerometro;

public class cPelota {
    //... atributos
    private int aNroP, aSelecP, aAncho, aAlto, aBorde;
    private int[][][] aCordXYZ; //nivel-aCordX, aCordY, aCordZ/aRadio, activo, opcional;
    //... constructor
    protected cPelota(int pNroP, int pAncho, int pAlto){
        aNroP= pNroP; aSelecP= 0;
        aAncho= pAncho; aAlto= pAlto;
        aCordXYZ= new int[aNroP][2][3];
        //... iniciar pelotas
        iniciarCoordenada();
    }
    //... metodos privados
    private void iniciarCoordenada(){
        int x=100, y= 100, z= 0;
        for(int i= 0; i<aNroP; i++){
            //... coordenada Z - X - Y
            aCordXYZ[i][0][0]= x; aCordXYZ[i][0][1]= y; aCordXYZ[i][0][2]= z;
            //... radio - activo - opcional
            aCordXYZ[i][1][0]= 50; aCordXYZ[i][1][1]= 1; aCordXYZ[i][1][2]= 0;
            x= x+150;
            if(x>aAncho){
                x= 100;
                y= y+150;
            }
        }
    }
    //... selectores
    public int sNroP(){ return aNroP; }
    public int sCordXYZ(int pZ, int pX, int pY){ return aCordXYZ[pZ][pX][pY]; }
    //... otros metodos
    public void escogerPelota(int pCordX, int pCordY){
        for(int i= 0; i<aNroP; i++){
            if(pCordX>=aCordXYZ[i][0][0]-aCordXYZ[i][1][0] && pCordX<=aCordXYZ[i][0][0]+aCordXYZ[i][1][0] &&
                    pCordY>=aCordXYZ[i][0][1]-aCordXYZ[i][1][0] && pCordY<=aCordXYZ[i][0][1]+aCordXYZ[i][1][0] &&
                    aCordXYZ[i][1][1]==1) {
                aSelecP= i;
                i= aNroP;
            }
        }
    }
    public void moverPelota(int pCordX, int pCordY, int pCordZ){
        //... capturando coordenada X
        aCordXYZ[aSelecP][0][0]= aCordXYZ[aSelecP][0][0]-pCordX;
        if(aCordXYZ[aSelecP][0][0]<aCordXYZ[aSelecP][1][0]+aBorde){
            //... para que no se vaya muy a la izquierda
            aCordXYZ[aSelecP][0][0]= aCordXYZ[aSelecP][1][0]+aBorde;
        }else if(aCordXYZ[aSelecP][0][0]>aAncho-(aCordXYZ[aSelecP][1][0]+aBorde)){
            //... para que no se vaya muy a la derecha
            aCordXYZ[aSelecP][0][0]= aAncho-(aCordXYZ[aSelecP][1][0]+aBorde);
        }
        //... capturando coordenada Y
        aCordXYZ[aSelecP][0][1]= aCordXYZ[aSelecP][0][1]+pCordY;
        if(aCordXYZ[aSelecP][0][1]<aCordXYZ[aSelecP][1][0]+aBorde){
            //... para que no se vaya muy arriba
            aCordXYZ[aSelecP][0][1]= aCordXYZ[aSelecP][1][0]+aBorde;
        }else if(aCordXYZ[aSelecP][0][1]>aAlto-(aCordXYZ[aSelecP][1][0]+170)){
            //... los 170 equivale a cabecera de activity
            aCordXYZ[aSelecP][0][1]= aAlto-(aCordXYZ[aSelecP][1][0]+170);
        }
        //... capturando coordenada Z
        aCordXYZ[aSelecP][0][2]= pCordZ;
        //z= String.format("%2f", aCordZ);
    }
}
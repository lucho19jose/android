package com.example.operacion;

public class cOperacion {
    // ... atributos
    private int aNro1, aNro2;
    //... constructores
    protected cOperacion(){ aNro1 = 0; aNro2 = 0;}
    //... modificadores
    public void mNro1(int pNro1){ aNro1 = pNro1;}
    public void mNro2(int pNro2){ aNro2 = pNro2;}
    //... selectores
    public int sNro1(){return aNro1;}
    public int sNro2(){return aNro2;}
    //... métodos
    public int sumar(){
        return aNro1 + aNro2;
    }
    public int restar(){
        return aNro1 - aNro2;
    }
    public int multiplicar(){
        return aNro1 * aNro2;
    }
    public int dividir(){
        return aNro1 / aNro2;
    }

}

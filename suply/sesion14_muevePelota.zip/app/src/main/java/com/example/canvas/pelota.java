package com.example.canvas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class pelota extends AppCompatActivity implements View.OnTouchListener {
    private cGrafico aG;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pelota);
        //... establecer enlace
        ConstraintLayout lienzo= findViewById(R.id.clLienzo);
        aG= new cGrafico(this, getIntent().getStringExtra("figura"), getIntent().getFloatArrayExtra("datos"));
        aG.setOnTouchListener(this);
        //... recuperar datos
        lienzo.addView(aG);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        aG.coordenada((int)event.getX(), (int)event.getY());
        //... refresch de la clase grafico
        aG.invalidate();
        return true;
    }
    public void anterior(View view){
        Intent ant= new Intent(this, dato.class);
        startActivity(ant);
        finish();
    }
}
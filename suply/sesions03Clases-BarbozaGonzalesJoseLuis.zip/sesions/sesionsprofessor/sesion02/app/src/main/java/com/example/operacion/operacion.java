package com.example.operacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class operacion extends AppCompatActivity {
    //... declarar atributos
    private EditText aNro1, aNro2;
    private TextView aRta;
    //... class
    private cOperacion aO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.operacion);
        //... establecer enlace
        aNro1= findViewById(R.id.etNro1);
        aNro2= findViewById(R.id.etNro2);
        aRta= findViewById(R.id.tvRta);
        //... declarar clase
        aO = new cOperacion();
    }
    public void sumar(View view){
        //... asignar varibales
        aO.mNro1(Integer.parseInt(aNro1.getText().toString()));
        aO.mNro2(Integer.parseInt(aNro2.getText().toString()));
        //... mostrar resultado
        aRta.setText("Respuesta: "+ aO.sumar());
    }
    public void restar(View view){
        //... asignar varibales
        aO.mNro1(Integer.parseInt(aNro1.getText().toString()));
        aO.mNro2(Integer.parseInt(aNro2.getText().toString()));
        //... mostrar resultado
        aRta.setText("Respuesta: "+ aO.restar());
    }
    public void multiplicar(View view){
        //... asignar varibales
        aO.mNro1(Integer.parseInt(aNro1.getText().toString()));
        aO.mNro2(Integer.parseInt(aNro2.getText().toString()));
        //... mostrar resultado
        aRta.setText("Respuesta: "+ aO.multiplicar());
    }
    public void dividir(View view){
        //... asignar varibales
        aO.mNro1(Integer.parseInt(aNro1.getText().toString()));
        aO.mNro2(Integer.parseInt(aNro2.getText().toString()));
        //... mostrar resultado
        aRta.setText("Respuesta: "+ aO.dividir());
    }
}
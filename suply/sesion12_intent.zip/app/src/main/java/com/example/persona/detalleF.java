package com.example.persona;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class detalleF extends AppCompatActivity {
    private TextView aDatoP;
    private String[] persona;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_f);
        //... establecer enlace
        aDatoP= findViewById(R.id.tvDatoP);
        //... recuperar datos
        persona= getIntent().getStringArrayExtra("persona");
        mostrarDatos(persona);
    }
    //... metodos privados
    private void mostrarDatos(String[] pPersona){
        String dato= "DNI: "+pPersona[0]+"\n";
        dato= dato+"Apellidos: "+pPersona[1]+"\n";
        dato= dato+"Nombres: "+pPersona[2]+"\n";
        aDatoP.setText(dato);
    }
    public void anterior(View view){
        Intent ant= new Intent(this, formulario.class);
        startActivity(ant);
        finish();
    }
}
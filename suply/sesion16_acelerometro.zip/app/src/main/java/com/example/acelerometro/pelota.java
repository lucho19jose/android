package com.example.acelerometro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class pelota extends AppCompatActivity implements View.OnTouchListener{
    //... atributos
    private cGrafico aP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pelota);
        //... establecer enlace
        ConstraintLayout lienzo= findViewById(R.id.clLienzo);
        //... crear clase
        aP= new cGrafico(this);
        //... pintar
        lienzo.addView(aP);
        //... sensor touch
        aP.setOnTouchListener(this);
        //... sensor orientacion
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        aP.escogerPelota((int)motionEvent.getX(), (int)motionEvent.getY());
        aP.invalidate();
        return true;
    }
}